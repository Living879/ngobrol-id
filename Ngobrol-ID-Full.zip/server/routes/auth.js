
const express = require('express');
const router = express.Router();

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (username === 'admin' && password === 'admin') {
        res.json({ message: 'Login sukses!', token: 'dummy-token' });
    } else {
        res.status(401).json({ message: 'Username atau password salah' });
    }
});

router.post('/register', (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(400).json({ message: 'Lengkapi semua data' });
    }
    res.json({ message: 'Registrasi berhasil!', success: true });
});

module.exports = router;
